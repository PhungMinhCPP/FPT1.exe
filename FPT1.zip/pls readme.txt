FPT1.exe
Created by: Pminh141
Malware type: Trojan
Made in: C++, asm
Works Bests In: Windows XP
my new short extreme trojan